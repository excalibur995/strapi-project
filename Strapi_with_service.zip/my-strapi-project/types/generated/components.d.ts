import type { Schema, Struct } from '@strapi/strapi';

export interface DynamicScreenContentFieldsAction
  extends Struct.ComponentSchema {
  collectionName: 'components_dynamic_screen_content_fields_actions';
  info: {
    displayName: 'action';
  };
  attributes: {
    event: Schema.Attribute.Enumeration<['SAVE_DRAFT']>;
    target: Schema.Attribute.String;
    type: Schema.Attribute.Enumeration<['SUBMIT_FORM', 'EMIT_EVENT']> &
      Schema.Attribute.Required;
  };
}

export interface DynamicScreenContentFieldsProps
  extends Struct.ComponentSchema {
  collectionName: 'components_dynamic_screen_content_fields_props';
  info: {
    displayName: 'props';
  };
  attributes: {
    label: Schema.Attribute.String;
  };
}

export interface DynamicScreenContentBase extends Struct.ComponentSchema {
  collectionName: 'components_dynamic_screen_content_bases';
  info: {
    displayName: 'base';
  };
  attributes: {
    groupId: Schema.Attribute.String;
    rowId: Schema.Attribute.String;
  };
}

export interface DynamicScreenContentButton extends Struct.ComponentSchema {
  collectionName: 'components_dynamic_screen_content_buttons';
  info: {
    displayName: 'button';
  };
  attributes: {
    action: Schema.Attribute.Component<
      'dynamic-screen-content-fields.action',
      false
    >;
    config: Schema.Attribute.Component<'dynamic-screen-content.base', false>;
    props: Schema.Attribute.Component<
      'dynamic-screen-content-fields.props',
      false
    >;
    role: Schema.Attribute.String;
    type: Schema.Attribute.String;
  };
}

export interface DynamicScreenContentLabel extends Struct.ComponentSchema {
  collectionName: 'components_dynamic_screen_content_labels';
  info: {
    displayName: 'label';
  };
  attributes: {
    config: Schema.Attribute.Component<'dynamic-screen-content.base', false>;
    text: Schema.Attribute.String;
    variant: Schema.Attribute.String;
  };
}

export interface DynamicScreenFooter extends Struct.ComponentSchema {
  collectionName: 'components_dynamic_screen_footers';
  info: {
    displayName: 'footer';
  };
  attributes: {
    disclaimerText: Schema.Attribute.String;
    primaryButton: Schema.Attribute.Component<
      'dynamic-screen-content.button',
      false
    >;
    secondaryButton: Schema.Attribute.Component<
      'dynamic-screen-content.button',
      false
    >;
    sticky: Schema.Attribute.Boolean;
  };
}

export interface DynamicScreenHeader extends Struct.ComponentSchema {
  collectionName: 'components_dynamic_screen_headers';
  info: {
    displayName: 'header';
  };
  attributes: {
    backButtonEnabled: Schema.Attribute.Boolean;
    image: Schema.Attribute.String;
    progressIndicator: Schema.Attribute.Boolean;
    subTitle: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface NotificationChannel extends Struct.ComponentSchema {
  collectionName: 'components_notification_channels';
  info: {
    displayName: 'channel';
  };
  attributes: {
    email: Schema.Attribute.Component<'notification.channel-content', false>;
    notificationCenter: Schema.Attribute.Component<
      'notification.channel-notification-content',
      false
    >;
    push: Schema.Attribute.Component<'notification.channel-content', false>;
    sms: Schema.Attribute.Component<'notification.channel-content', false>;
    webInbox: Schema.Attribute.Component<'notification.channel-content', false>;
  };
}

export interface NotificationChannelContent extends Struct.ComponentSchema {
  collectionName: 'components_notification_channel_contents';
  info: {
    displayName: 'channelBasicContent';
  };
  attributes: {
    postContent: Schema.Attribute.String;
    preContent: Schema.Attribute.String;
  };
}

export interface NotificationChannelNotificationContent
  extends Struct.ComponentSchema {
  collectionName: 'components_notification_channel_notification_contents';
  info: {
    displayName: 'channelNotificationContent';
  };
  attributes: {
    image: Schema.Attribute.String;
    postContent: Schema.Attribute.String;
    preContent: Schema.Attribute.String;
  };
}

export interface ScreenContentButtons extends Struct.ComponentSchema {
  collectionName: 'components_screen_content_buttons';
  info: {
    displayName: 'buttons';
  };
  attributes: {
    label: Schema.Attribute.String;
    variant: Schema.Attribute.String;
  };
}

export interface ScreenContentConsent extends Struct.ComponentSchema {
  collectionName: 'components_screen_content_consents';
  info: {
    displayName: 'consent';
  };
  attributes: {
    fields: Schema.Attribute.Component<'screen-content.fields', true>;
    html: Schema.Attribute.Text;
  };
}

export interface ScreenContentContent extends Struct.ComponentSchema {
  collectionName: 'components_screen_content_contents';
  info: {
    displayName: 'content';
  };
  attributes: {
    buttons: Schema.Attribute.Component<'screen-content.buttons', true>;
    consent: Schema.Attribute.Component<'screen-content.consent', true>;
    indicators: Schema.Attribute.Component<'screen-content.indicators', true>;
    logo: Schema.Attribute.String;
    options: Schema.Attribute.Component<'screen-content.menu', true>;
    sliders: Schema.Attribute.Component<'screen-content.sliders', true>;
    title: Schema.Attribute.String;
    type: Schema.Attribute.String;
  };
}

export interface ScreenContentFields extends Struct.ComponentSchema {
  collectionName: 'components_screen_content_fields';
  info: {
    displayName: 'fields';
  };
  attributes: {
    description: Schema.Attribute.Text;
    type: Schema.Attribute.String;
  };
}

export interface ScreenContentIndicators extends Struct.ComponentSchema {
  collectionName: 'components_screen_content_indicators';
  info: {
    displayName: 'indicators';
  };
  attributes: {
    name: Schema.Attribute.String;
  };
}

export interface ScreenContentMenu extends Struct.ComponentSchema {
  collectionName: 'components_screen_content_menus';
  info: {
    displayName: 'options';
  };
  attributes: {
    name: Schema.Attribute.String;
  };
}

export interface ScreenContentSliders extends Struct.ComponentSchema {
  collectionName: 'components_screen_content_sliders';
  info: {
    displayName: 'sliders';
  };
  attributes: {
    description: Schema.Attribute.String;
    image: Schema.Attribute.String;
    title: Schema.Attribute.String;
  };
}

export interface SharedMedia extends Struct.ComponentSchema {
  collectionName: 'components_shared_media';
  info: {
    displayName: 'Media';
    icon: 'file-video';
  };
  attributes: {
    file: Schema.Attribute.Media<'images' | 'files' | 'videos'>;
  };
}

export interface SharedQuote extends Struct.ComponentSchema {
  collectionName: 'components_shared_quotes';
  info: {
    displayName: 'Quote';
    icon: 'indent';
  };
  attributes: {
    body: Schema.Attribute.Text;
    title: Schema.Attribute.String;
  };
}

export interface SharedRichText extends Struct.ComponentSchema {
  collectionName: 'components_shared_rich_texts';
  info: {
    description: '';
    displayName: 'Rich text';
    icon: 'align-justify';
  };
  attributes: {
    body: Schema.Attribute.RichText;
  };
}

export interface SharedSeo extends Struct.ComponentSchema {
  collectionName: 'components_shared_seos';
  info: {
    description: '';
    displayName: 'Seo';
    icon: 'allergies';
    name: 'Seo';
  };
  attributes: {
    metaDescription: Schema.Attribute.Text & Schema.Attribute.Required;
    metaTitle: Schema.Attribute.String & Schema.Attribute.Required;
    shareImage: Schema.Attribute.Media<'images'>;
  };
}

export interface SharedSlider extends Struct.ComponentSchema {
  collectionName: 'components_shared_sliders';
  info: {
    description: '';
    displayName: 'Slider';
    icon: 'address-book';
  };
  attributes: {
    files: Schema.Attribute.Media<'images', true>;
  };
}

export interface SharedTextList extends Struct.ComponentSchema {
  collectionName: 'components_shared_text_lists';
  info: {
    displayName: 'textList';
    icon: 'book';
  };
  attributes: {};
}

declare module '@strapi/strapi' {
  export module Public {
    export interface ComponentSchemas {
      'dynamic-screen-content-fields.action': DynamicScreenContentFieldsAction;
      'dynamic-screen-content-fields.props': DynamicScreenContentFieldsProps;
      'dynamic-screen-content.base': DynamicScreenContentBase;
      'dynamic-screen-content.button': DynamicScreenContentButton;
      'dynamic-screen-content.label': DynamicScreenContentLabel;
      'dynamic-screen.footer': DynamicScreenFooter;
      'dynamic-screen.header': DynamicScreenHeader;
      'notification.channel': NotificationChannel;
      'notification.channel-content': NotificationChannelContent;
      'notification.channel-notification-content': NotificationChannelNotificationContent;
      'screen-content.buttons': ScreenContentButtons;
      'screen-content.consent': ScreenContentConsent;
      'screen-content.content': ScreenContentContent;
      'screen-content.fields': ScreenContentFields;
      'screen-content.indicators': ScreenContentIndicators;
      'screen-content.menu': ScreenContentMenu;
      'screen-content.sliders': ScreenContentSliders;
      'shared.media': SharedMedia;
      'shared.quote': SharedQuote;
      'shared.rich-text': SharedRichText;
      'shared.seo': SharedSeo;
      'shared.slider': SharedSlider;
      'shared.text-list': SharedTextList;
    }
  }
}
