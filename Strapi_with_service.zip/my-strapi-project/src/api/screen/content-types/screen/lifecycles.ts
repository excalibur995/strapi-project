import { errors } from '@strapi/utils'
const { ValidationError } = errors;

module.exports = {
  async beforeCreate(event) {
    console.log("beforeCreate");
    const { data } = event.params;

    // const existing = await strapi.documents('api::screen.screen').findMany({
    //   filters: {
    //     screenId: data.screenId,
    //     version: data.version,
    //   },
    // });

    // if (existing.length > 0) {
    //   throw new ValidationError(
    //     `Duplicate DisplayName not allowed: ${data.screenId} v${data.version}`
    //   );
    // }

    data.displayName = `${data.screenId} (v${data.version})`;
  },

  async beforeUpdate(event) {
    console.log("beforeUpdate");
    const { data } = event.params;
    if (data.screenId || data.version) {
      data.displayName = `${data.screenId} (v${data.version})`;
    }
  },
};