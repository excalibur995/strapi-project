/**
 * screen controller
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::screen.screen', ({ strapi }) => ({
  async findOne(ctx) {
    const { id } = ctx.params;

    const sanitizedQuery = await this.sanitizeQuery(ctx);

    console.log(sanitizedQuery);

    const entity = await strapi.documents("api::screen.screen").findOne({
      documentId: id,
      ...sanitizedQuery,
      populate: {
        content: { 
            populate: {
                buttons: { populate: "*" },
                options: { populate: "*" },
                sliders: { populate: "*" },
                indicators: { populate: "*" },
                consent: { populate: "*" }
            }
        }
      }
    });

    if (!entity) {
      return ctx.notFound(`Screen not found`);
    }

    console.log(entity);

    const sanitizedEntity = await this.sanitizeOutput(entity, ctx);
    return this.transformResponse(sanitizedEntity);
  },
}));
