/**
 * dynamic-screen service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::dynamic-screen.dynamic-screen');
