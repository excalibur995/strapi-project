/**
 * dynamic-screen controller
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::dynamic-screen.dynamic-screen');
