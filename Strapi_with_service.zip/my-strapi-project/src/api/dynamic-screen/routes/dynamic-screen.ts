/**
 * dynamic-screen router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::dynamic-screen.dynamic-screen');
