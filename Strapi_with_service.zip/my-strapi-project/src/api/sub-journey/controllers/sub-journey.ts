/**
 * sub-journey controller
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::sub-journey.sub-journey');
