/**
 * sub-journey service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::sub-journey.sub-journey');
