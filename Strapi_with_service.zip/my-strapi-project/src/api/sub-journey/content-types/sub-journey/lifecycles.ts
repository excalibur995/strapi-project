module.exports = {
  async beforeCreate(event) {
    const { data } = event.params;
    data.displayName = `${data.subJourneyId} (v${data.version})`;
  },

  async beforeUpdate(event) {
    const { data } = event.params;
    if (data.subJourneyId || data.version) {
      data.displayName = `${data.subJourneyId} (v${data.version})`;
    }
  },
};