export default {
  async getNotificationProjection(ctx) {
    const { templateId } = ctx.params;
    const { locale, version } = ctx.query;

    const entries = await strapi.entityService.findMany('api::notification.notification', {
      filters: {
        templateId,
        locale: locale || "en",
        ...(version && version !== "latest" && { version }),
      },
      sort: version === "latest" || !version ? { version: 'desc' } : {},
      populate: {
        channel: { 
            populate: {
                push: true,
                sms: true,
                notificationCenter: true,
                webInbox: true,
                email: true
            }
        }
      },
      limit: 1,
    });

    const entry = entries?.[0];

    if (!entry) {
      return ctx.notFound('Content not found');
    }

    const projection = strapi
        .service('api::notification.notification-projection')
        .toNotificationProjection(entry);

    ctx.body = projection;
  },
};