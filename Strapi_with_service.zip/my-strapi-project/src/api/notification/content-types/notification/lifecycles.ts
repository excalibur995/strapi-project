import { errors } from '@strapi/utils'
const { ValidationError } = errors;

module.exports = {
  async beforeCreate(event) {
    console.log("beforeCreate");
    const { data } = event.params;

    // const existing = await strapi.documents('api::notification.notification').findMany({
    //   filters: {
    //     templateId: data.templateId,
    //     version: data.version,
    //   },
    // });

    // if (existing.length > 0) {
    //   throw new ValidationError(
    //     `Duplicate uuid not allowed: ${data.templateId}-${data.version}`
    //   );
    // }

    data.displayName = `${data.title} (v${data.version})`;
    data.uuid = `${data.templateId}-${data.version}`;
  },

  async beforeUpdate(event) {
    console.log("beforeUpdate");
    const { data } = event.params;
    if (data.title || data.version) {
      data.displayName = `${data.title} (v${data.version})`;
      data.uuid = `${data.templateId}-${data.version}`;
    }
  },
};