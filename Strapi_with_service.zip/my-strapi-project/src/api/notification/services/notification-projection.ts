const KEYS_TO_REMOVE = new Set([
    "id"
]);

const cleanValue = (value: any): any => {
    // Handle arrays
    if (Array.isArray(value)) {
        const cleanedArray = value.map(cleanValue).filter((item) => item !== undefined);

        // Remove array if empty
        return cleanedArray.length > 0 ? cleanedArray : undefined;
    }

    // Handle objects
    if (value && typeof value === "object") {
        const cleanedObject: Record<string, any> = {};

        for (const [key, childValue] of Object.entries(value)) {
            // Remove unwanted keys
            if (KEYS_TO_REMOVE.has(key)) {
                continue;
            }

            // Remove null values
            // if (childValue === null) {
            //     continue;
            // }

            const cleanedChild = cleanValue(childValue);

            // Skip undefined results
            if (cleanedChild === undefined) {
                continue;
            }

            cleanedObject[key] = cleanedChild;
        }

        // Remove object if it becomes empty
        return Object.keys(cleanedObject).length > 0 ? cleanedObject : undefined;
    }

    // Keep primitive values
    return value;
}

export default () => ({
  toNotificationProjection(entry: any) {
    return {
      templateId: entry.templateId,
      category: entry.category,
      title: entry.title,
      content: entry.content,
      channel: cleanValue(entry.channel)
    };
  },
});