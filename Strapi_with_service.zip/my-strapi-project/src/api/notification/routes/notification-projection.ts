export default {
  routes: [
    {
      method: 'GET',
      path: '/notification-template/:templateId',
      handler: 'notification-projection.getNotificationProjection',
      config: {
        auth: false,
      },
    },
  ],
};