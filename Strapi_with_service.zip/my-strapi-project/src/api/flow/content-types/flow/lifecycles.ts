module.exports = {
  async beforeCreate(event) {
    const { data } = event.params;
    data.displayName = `${data.flowId} (v${data.version})`;
  },

  async beforeUpdate(event) {
    const { data } = event.params;
    if (data.flowId || data.version) {
      data.displayName = `${data.flowId} (v${data.version})`;
    }
  },
};