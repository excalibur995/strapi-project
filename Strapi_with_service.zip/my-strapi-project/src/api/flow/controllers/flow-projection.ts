export default {
  async getFlowProjection(ctx) {
    const { flowId, version } = ctx.params;
    const { locale } = ctx.query;

    const entries = await strapi.entityService.findMany('api::flow.flow', {
      filters: {
        flowId,
        version,
        locale: locale ? locale : "en"
      },
      populate: {
        screens: { 
            populate: {
                content: { 
                    populate: {
                        buttons: { populate: "*" },
                        options: { populate: "*" },
                        sliders: { populate: "*" },
                        indicators: { populate: "*" },
                        consent: { populate: "*" }
                    }
                }
            }
        }
      },
      limit: 1,
    });

    const entry = entries?.[0];

    if (!entry) {
      return ctx.notFound('Content not found');
    }

    const projection = strapi
        .service('api::flow.flow-projection')
        .toFlowProjection(entry);

    ctx.body = projection;
  },
};