export default {
  routes: [
    {
      method: 'GET',
      path: '/flow/:flowId/:version',
      handler: 'flow-projection.getFlowProjection',
      config: {
        auth: false,
      },
    },
  ],
};