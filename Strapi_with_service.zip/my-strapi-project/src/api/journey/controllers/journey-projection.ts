export default {
  async getJourneyProjection(ctx) {
    const { journeyId, version } = ctx.params;
    const { locale } = ctx.query;

    const entries = await strapi.entityService.findMany('api::journey.journey', {
      filters: {
        journeyId,
        version,
        locale: locale ? locale : "en"
      },
      populate: {
        subJourneys: { 
          populate: {
            screens: { 
                populate: {
                    // content: true
                    content: { 
                        populate: {
                            // buttons: { populate: "*" },
                            // options: { populate: "*" },
                            // sliders: { populate: "*" },
                            // indicators: { populate: "*" },
                            // consent: { populate: "*" }
                            buttons: true,
                            options: true,
                            sliders: true,
                            indicators: true,
                            consent: true
                        }
                    }
                }
            }
          }
        }
      },
      limit: 1,
    });

    const entry = entries?.[0];

    if (!entry) {
      return ctx.notFound('Content not found');
    }

    const projection = strapi
        .service('api::journey.journey-projection')
        .toJourneyProjection(entry);

    ctx.body = projection;
  },
};