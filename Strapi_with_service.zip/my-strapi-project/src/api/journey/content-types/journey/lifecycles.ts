module.exports = {
  async beforeCreate(event) {
    const { data } = event.params;
    data.displayName = `${data.journeyId} (v${data.version})`;
  },

  async beforeUpdate(event) {
    const { data } = event.params;
    if (data.journeyId || data.version) {
      data.displayName = `${data.journeyId} (v${data.version})`;
    }
  },
};