import journey from "./journey";

const KEYS_TO_REMOVE = new Set([
    "id",
    "locale",
    "createdAt",
    "updatedAt",
    "publishedAt",
    "documentId",
    "displayName"
]);

const cleanValue = (value: any): any => {
    // Handle arrays
    if (Array.isArray(value)) {
        const cleanedArray = value.map(cleanValue).filter((item) => item !== undefined);

        // Remove array if empty
        return cleanedArray.length > 0 ? cleanedArray : undefined;
    }

    // Handle objects
    if (value && typeof value === "object") {
        const cleanedObject: Record<string, any> = {};

        for (const [key, childValue] of Object.entries(value)) {
            // Remove unwanted keys
            if (KEYS_TO_REMOVE.has(key)) {
                continue;
            }

            // Remove null values
            if (childValue === null) {
                continue;
            }

            const cleanedChild = cleanValue(childValue);

            // Skip undefined results
            if (cleanedChild === undefined) {
                continue;
            }

            cleanedObject[key] = cleanedChild;
        }

        // Remove object if it becomes empty
        return Object.keys(cleanedObject).length > 0 ? cleanedObject : undefined;
    }

    // Keep primitive values
    return value;
}

const cleanScreens = (screens: any[]) => screens.map(cleanValue).filter((screen) => screen !== undefined);

const cleanSubJourneys = (subJourneys: any[]) => {
    const sj = [];

    subJourneys.forEach(element => {
        const cleanSubJourneys = {
            subJourneyId: element.subJourneyId,
            version: element.version,
            screens: cleanScreens(element.screens)
        }
        sj.push(cleanSubJourneys);
    });

    return sj;
}

export default () => ({
  toJourneyProjection(entry: any) {
    return {
      journeyId: entry.journeyId,
      version: entry.version,
      subJourneys: cleanSubJourneys(entry.subJourneys)
    };
  },
});