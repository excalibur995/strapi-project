export default {
  routes: [
    {
      method: 'GET',
      path: '/journey/:journeyId/:version',
      handler: 'journey-projection.getJourneyProjection',
      config: {
        auth: false,
      },
    },
  ],
};