/**
 * translation-key router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::translation-key.translation-key');
