/**
 * translation-key service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::translation-key.translation-key');
